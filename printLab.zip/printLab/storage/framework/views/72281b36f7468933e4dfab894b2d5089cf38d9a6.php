<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Add Supplier'); ?>

<div class="hero-area section-bg2">
<div class="container">
<div class="row">
<div class="col-xl-12">
<div class="slider-area">
<div class="slider-height2 slider-bg4 d-flex align-items-center justify-content-center">
<div class="hero-caption hero-caption2">
<h2>Track Orders</h2>
<nav aria-label="breadcrumb">
<ol class="breadcrumb justify-content-center">
<li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
<li class="breadcrumb-item"><a href="#">Track Orders</a></li>
</ol>
</nav>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="cart_area">
    <div class="container">
        <div class="cart_inner">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">S/N</th>
                            <th scope="col">Product</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Color</th>
                            <th scope="col">Paper Type</th>
                            <th scope="col">Thickness</th>
                            <th scope="col">Total</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $product_name = str_replace('_',' ', $val->productName->name)   ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <div class="media">
                                        <div class="d-flex">
                                            <img src="<?php echo e(asset('product_images/'.$val->productName->image)); ?>" alt />
                                        </div>
                                        <div class="media-body">
                                            <p><?php echo e(ucwords($product_name)); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <h5><?php echo e($val->quantity); ?></h5>
                                </td>
                                <td>
                                    <h5><?php echo e($val->ink); ?> Color</h5>
                                </td>
                                <td>
                                    <h5><?php echo e($val->paper_type); ?> Color</h5>
                                </td>
                                <td>
                                    <h5><?php echo e($val->thickness); ?></h5>
                                </td>
                                <td>
                                    <h5><?php echo e('₦'.$val->total_cost); ?></h5>
                                </td>
                                <td><a class="btn" href="<?php echo e(route('track_orders.view',$val->id)); ?>"><span >View Order</span></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.landing_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\printLab\resources\views/track_orders/index.blade.php ENDPATH**/ ?>