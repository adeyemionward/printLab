<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'All Products'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col-md-6 float-start">
                    <h4 class="m-0 text-dark text-muted">All Products</h4>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb float-end">
                        <li class="breadcrumb-item"><a href="#"> Products</a></li>
                        <li class="breadcrumb-item active">All Products</li>
                    </ol>
                </div>
            </div>

            <div class="card">
                <div class="content" id="tableContent">

                    <div class="canvas-wrapper">

                        <table id="example" class="table no-margin" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Product Name</th>
                                    <th>Description</th>
                                    <th>Ink</th>
                                    <th>Paper Type</th>
                                    <th>Production Days</th>
                                    <th>Proof Needed</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $product_name = str_replace(' ','_', $val->name)   ?>
                                <?php $product_name1 = str_replace('_',' ', $val->name)   ?>
                                    <tr>
                                        <td><?php echo e($index+1); ?></td>
                                        <td><?php echo e($product_name1); ?></td>

                                        <td><?php echo e($val->description); ?> </td>
                                        <td><?php echo e($val->ink); ?></td>
                                        <td><?php echo e($val->paper_type); ?></td>
                                        <td><?php echo e($val->production_days); ?></td>
                                        <td><?php echo e($val->proof_needed); ?> </td>
                                        <td><a href="<?php echo e(route('products.view',[$product_name, $val->id])); ?>"><span><i class="fa fa-eye"></i></span></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\printLab\resources\views/products/all_products.blade.php ENDPATH**/ ?>