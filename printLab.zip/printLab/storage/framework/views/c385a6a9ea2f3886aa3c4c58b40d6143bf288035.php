<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Product Details'); ?>
<div class="hero-area section-bg2">
    <div class="container">
    <div class="row">
    <div class="col-xl-12">
    <div class="slider-area">
    <div class="slider-height2 slider-bg4 d-flex align-items-center justify-content-center">
    <div class="hero-caption hero-caption2">
    <h2>Product Details</h2>
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb justify-content-center">
    <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Product Details</a></li>
    </ol>
    </nav>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>


    <div class="services-area2 pt-50">
    <div class="container">
    <div class="row">
    <div class="col-xl-12">
    <div class="row">
    <div class="col-xl-12">
    <form method="POST">
        <?php echo csrf_field(); ?>
        <div class="single-services d-flex align-items-center mb-0">
            <div class="features-img">
                <img src="<?php echo e(asset('product_images/'.$product->image)); ?>" alt>
                <center style="color:#fff; font-size:24px; padding-top:16px;"><label for="">Select Other Specifications</label></center>
                <div class="row">
                    <div class="form-group mt-3 mb-3 col-md-4">
                        <label for="" style="color: #fff">Color Type</label>
                        <select name="ink" class="form-control form-select"
                            id="ink">
                            <option value="single" <?php if($product->ink == 'single') echo 'selected' ?>>Single Color</option>
                            <option value="full" <?php if($product->ink == 'full') echo 'selected' ?>>Full Color</option>
                        </select>
                    </div>
                    <div class="form-group mt-3 mb-3 col-md-4">
                        <label for="" style="color: #fff">Paper Type</label>
                        <select name="paper_type" class="form-control form-select"  id="paper_type">
                            <option value="50g" <?php if($product->paper_type == '50g') echo 'selected' ?>>50g</option>
                            <option value="60g" <?php if($product->paper_type == '60g') echo 'selected' ?>>60g</option>
                            <option value="70g" <?php if($product->paper_type == '70g') echo 'selected' ?>>70g</option>
                            <option value="80g" <?php if($product->paper_type == '80g') echo 'selected' ?>>80g</option>
                        </select>
                    </div>
                    <div class="form-group mt-3 mb-3 col-md-4">
                        <label for="" style="color: #fff">Thickness</label>
                        <select class="form-control form-select"  name="thickness" id="thickness">
                            <option value="199g" <?php if($product->thickness == '199g') echo 'selected' ?>>199g</option>
                            <option value="280g" <?php if($product->thickness == '280g') echo 'selected' ?>>280g</option>
                            <option value="300g" <?php if($product->thickness == '300g') echo 'selected' ?>>300g</option>
                        </select>
                    </div>
                </div>
                <p style="color: #fff">NOTE: You will be contacted on delivery processes as soon as we receive your order</p>
            </div>
            <?php if(request()->title == 'Higher_Education'): ?>
                <div class="features-caption">
                    <h3>Higher Education NoteBook</h3>

                    <input type="hidden" value="higher_notebook" id="product_name" name="product_name">
                    <p><b style="color: white; font-size:24px"> Description: </b> <span style="font-size:21px"><?php echo e($product->description); ?></span></p>
                    <p><b style="color: white; font-size:24px"> Specifications: </b>
                        <span>
                            <ul style="color: #fff;font-size:21px; margin-top:-22px; margin-left:20px">
                                <li style="list-style-type: square">
                                    <?php echo e(ucfirst($product->ink).' Color'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->paper_type.' Paper'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->thickness.' Thickness'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->production_days.' Production Days'); ?>

                                </li>
                            </ul>
                        </span></p>
                    <div class="price">
                        <input type="hidden" value="<?php echo e($product_cost->total_cost); ?>" id="total_cost" name="total_cost">
                        <span id="price-container">&#8358;<?php echo e($product_cost->total_cost); ?></span>
                    </div>


                    <div class="row">
                        <div class="form-group mt-3 mb-3 col-md-6">

                            <select name="quantity"  class="form-control form-select j-btn"  id="quantity">
                                <?php $__currentLoopData = $product_costs_higher_education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->quantity); ?>"><?php echo e($val->quantity); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mt-3 mb-3 col-md-6">
                            <button href="" type="submit" style="background: black; color:#fff; font-size:20px" class="white-btn mr-10">Order Now</button>
                        </div>
                    </div>
                    </div>


                </div>
            <?php endif; ?>

            <?php if(request()->title == 'Eighty_Leaves'): ?>
                <div class="features-caption">
                    <h3>Eighty Leaves</h3>

                    <input type="hidden" value="eighty_leaves" id="product_name" name="product_name">
                    <p><b style="color: white; font-size:24px"> Description: </b> <span style="font-size:21px"><?php echo e($product->description); ?></span></p>
                    <p><b style="color: white; font-size:24px"> Specifications: </b>
                        <span>
                            <ul style="color: #fff;font-size:21px; margin-top:-22px; margin-left:20px">
                                <li style="list-style-type: square">
                                    <?php echo e(ucfirst($product->ink).' Color'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->paper_type.' Paper'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->thickness.' Thickness'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->production_days.' Production Days'); ?>

                                </li>
                            </ul>
                        </span></p>
                    <div class="price">
                        <input type="hidden" value="<?php echo e($product_cost->total_cost); ?>" id="total_cost" name="total_cost">
                        <span id="price-container">&#8358;<?php echo e($product_cost->total_cost); ?></span>
                    </div>


                    <div class="row">
                        <div class="form-group mt-3 mb-3 col-md-4">

                            <select name="quantity"  class="form-control form-select j-btn"  id="quantity">
                                <?php $__currentLoopData = $product_costs_eighty_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->quantity); ?>"><?php echo e($val->quantity); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mt-3 mb-3 col-md-8">
                            <button href="" type="submit" style="background: black; color:#fff; font-size:20px" class="white-btn mr-10">Add to Cart</button>
                        </div>
                    </div>
                    </div>


                </div>
            <?php endif; ?>

            <?php if(request()->title == 'Forty_Leaves'): ?>
                <div class="features-caption">
                    <h3>Forty Leaves</h3>
                    <input type="hidden" value="forty_leaves" id="product_name" name="product_name">
                    <p><b style="color: white; font-size:24px"> Description: </b> <span style="font-size:21px"><?php echo e($product->description); ?></span></p>
                    <p><b style="color: white; font-size:24px"> Specifications: </b>
                        <span>
                            <ul style="color: #fff;font-size:21px; margin-top:-22px; margin-left:20px">
                                <li style="list-style-type: square">
                                    <?php echo e(ucfirst($product->ink).' Color'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->paper_type.' Paper'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->thickness.' Thickness'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->production_days.' Production Days'); ?>

                                </li>
                            </ul>
                        </span></p>
                    <div class="price">
                        <input type="text" value="<?php echo e($product_cost->total_cost); ?>" id="total_cost" name="total_cost">
                        <span id="price-container">&#8358;<?php echo e($product_cost->total_cost); ?></span>
                    </div>


                    <div class="row">
                        <div class="form-group mt-3 mb-3 col-md-4">

                            <select name="quantity"  class="form-control form-select j-btn"  id="quantity">
                                <?php $__currentLoopData = $product_costs_forty_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->quantity); ?>"><?php echo e($val->quantity); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mt-3 mb-3 col-md-8">
                            <button href="" type="submit" style="background: black; color:#fff; font-size:20px" class="white-btn mr-10">Add to Cart</button>
                        </div>
                    </div>
                    </div>


                </div>
            <?php endif; ?>

            <?php if(request()->title == 'Twenty_Leaves'): ?>
                <div class="features-caption">
                    <h3>Twenty Leaves</h3>
                    <input type="hidden" value="twenty_leaves" id="product_name" name="product_name">
                    <p><b style="color: white; font-size:24px"> Description: </b> <span style="font-size:21px"><?php echo e($product->description); ?></span></p>
                    <p><b style="color: white; font-size:24px"> Specifications: </b>
                        <span>
                            <ul style="color: #fff;font-size:21px; margin-top:-22px; margin-left:20px">
                                <li style="list-style-type: square">
                                    <?php echo e(ucfirst($product->ink).' Color'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->paper_type.' Paper'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->thickness.' Thickness'); ?>

                                </li>
                                <li style="list-style-type: square">
                                    <?php echo e($product->production_days.' Production Days'); ?>

                                </li>
                            </ul>
                        </span></p>
                    <div class="price">
                        <input type="hidden" value="<?php echo e($product_cost->total_cost); ?>" id="total_cost" name="total_cost">
                        <span id="price-container">&#8358;<?php echo e($product_cost->total_cost); ?></span>
                    </div>

                    <div class="row">
                        <div class="form-group mt-3 mb-3 col-md-4">

                            <select name="quantity"  class="form-control form-select j-btn"  id="quantity">
                                <?php $__currentLoopData = $product_costs_twenty_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->quantity); ?>"><?php echo e($val->quantity); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mt-3 mb-3 col-md-8">
                            <button href="" type="submit" style="background: black; color:#fff; font-size:20px" class="white-btn mr-10">Add to Cart</button>
                        </div>
                    </div>
                </div>

                </div>
            <?php endif; ?>

        </div>
    </form>

    </div>
    </div>
    </div>
    </div>
    </div>
    </div>


        </main> <br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function() {
        $('select').change(function() {
            var ink = $('#ink').val();
            var paper_type = $('#paper_type').val();
            var thickness = $('#thickness').val();
            var quantity = $('#quantity').val();
            var product_name = $('#product_name').val();
            var total_cost = $('#total_cost').val();
            // Collect values from other dropdowns as needed

            $.ajax({
                url: "<?php echo e(route('get_price')); ?>",
                type: "POST",
                data: {
                    ink: ink,
                    paper_type: paper_type,
                    thickness: thickness,
                    quantity: quantity,
                    product_name: product_name,
                    total_cost: total_cost,
                    // Add other specifications as needed
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {

                    $('#price-container').html(response.price);
                    $('#total_cost').val(response.price);
                    //alert(response.price);
                },
                error: function(error) {
                    console.error(error);
                    // Handle error gracefully, e.g., display an error message
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.landing_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\printLab\resources\views/product_details.blade.php ENDPATH**/ ?>