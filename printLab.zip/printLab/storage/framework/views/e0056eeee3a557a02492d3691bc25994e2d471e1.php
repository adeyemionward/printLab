<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $page = 'higher_education' ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col-md-6 float-start">
                    <h4 class="m-0 text-dark text-muted">Product</h4>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb float-end">
                        <li class="breadcrumb-item"><a href="#"> Home</a></li>
                        <li class="breadcrumb-item active">Productr</li>
                    </ol>
                </div>
            </div>

            <div class="content">
                <div class="canvas-wrapper">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <?php echo $__env->make('products.product_inc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="col-md-9 col-xl-9">
                                    <div class="card">
                                        <div class="card-header bg-white">
                                            <h5 class="card-title mb-0 text-muted">Create Higher Education Product</h5>
                                        </div>
                                        <div class="card-body h-100">
                                            <div class="align-items-start">
                                                <div class="tab-content" id="nav-tabContent">
                                                    <div class="tab-pane fade show active" id="nav-server"
                                                        role="tabpanel" aria-labelledby="nav-server-tab">

                                                        <div class="row g-3 mb-3 mt-3">
                                                            <div class="col-md-12">
                                                                <form method="POST"  id="add_twenty_leaves" class="add_twenty_leaves">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('POST'); ?>
                                                                    <div class="row">
                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="production_time">Product Name</label>
                                                                            <select name="product_name" class="form-control<?php echo e($errors->has('product_name') ? ' is-invalid' : ''); ?> form-select" value="<?php echo e(old('product_name')); ?>">
                                                                                <option value="higher_education">Higher Education</option>
                                                                                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </select>
                                                                        </div>



                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="exampleFormControlSelect1">Default Ink

                                                                            </label>
                                                                            <select name="ink" class="form-control form-select"
                                                                                id="exampleFormControlSelect1">
                                                                                <option value="">--Select Default Ink--</option>
                                                                                <option value="black">Black</option>
                                                                                <option value="full ink">Full Ink</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="paper_type">Default Paper Type
                                                                                </label>
                                                                            <select name="paper_type" class="form-control form-select"  id="exampleFormControlSelect1">
                                                                                <option value="">--Select Default Paper Type--</option>
                                                                                <option value="2 Part White | Canary">2 Part White | Canary</option>
                                                                                <option value="2 Part White | Pink">2 Part White | Pink</option>
                                                                                <option value="3 Part White | Canary | Pink">3 Part White | Canary | Pink</option>
                                                                                <option value="4 Part White | Canary | Pink | Goldenrod">4 Part White | Canary | Pink | Goldenrod</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">


                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="production_time">Production Time (Days)
                                                                                </label> <input required type="number" name="production_time" class="form-control"
                                                                                id="quantity" placeholder="eg: 4">
                                                                        </div>

                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="backsided">Default Back  Sided Print</label>
                                                                            <select class="form-control form-select"  name="back_sided_print" id="backsided">
                                                                                <option value="">--Select Default Back Sided Print--</option>
                                                                                <option value="yes">Yes</option>
                                                                                <option value="no">No</option>
                                                                            </select>
                                                                        </div>

                                                                        <div class="form-group mt-3 mb-3 col-md-4">
                                                                            <label for="proof_needed">Proof Needed</label>
                                                                            <select required class="form-control form-select"  name="proof_needed" id="proof_needed">
                                                                                <option value="">--Select Proof Needed--</option>
                                                                                <option value="yes">Yes</option>
                                                                                <option value="no">No</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">

                                                                        <div class="form-group mt-3 mb-3 col-md-12">
                                                                            <label for="address">Product Description
                                                                                </label>
                                                                                <textarea name="product_description"  class="form-control<?php echo e($errors->has('product_description') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('product_description')); ?>"
                                                                                id="product_description"></textarea>
                                                                                <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>



                                                                    </div>

                                                            </div>
                                                        </div>
                                                        <hr/>
                                                    </div>
                                                    <button class="btn btn-sm btn-danger" type="submit">
                                                        <i class="text-white me-2" data-feather="check-circle"></i>Save
                                                    </button>
                                                </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\printLab\resources\views/products/add_product.blade.php ENDPATH**/ ?>